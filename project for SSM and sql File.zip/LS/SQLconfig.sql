create database volunteerservice;
use volunteerservice;

create table admin(
adminID int AUTO_INCREMENT PRIMARY KEY,
adminName varchar(50),
password varchar(50)
);

create table volunteer(
volunteerID int AUTO_INCREMENT PRIMARY KEY,
volunteerName varchar(50),
password varchar(50)
);

create table teacher(
teacherID int AUTO_INCREMENT PRIMARY KEY,
teacherName varchar(50),
password varchar(50)
);

create table volProject(
projectID int AUTO_INCREMENT PRIMARY KEY,
projectName varchar(50)
);

create table volJoin(
JoinID int AUTO_INCREMENT PRIMARY KEY,
volunteerID int,
teacherID int,
projectID int,
score float,
);
