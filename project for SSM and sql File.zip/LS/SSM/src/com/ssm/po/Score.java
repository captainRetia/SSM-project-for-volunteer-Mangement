package com.ssm.po;

public class Score {
	private int JoinID;
	private float score;
	private int volunteerID;
	private int teacherID;
	private int projectID;
	public int getJoinID() {
		return JoinID;
	}
	public void setJoinID(int JoinID) {
		this.JoinID = JoinID;
	}
	public float getScore() {
		return score;
	}
	public void setScore(float score) {
		this.score = score;
	}
	public int getVolunteerID() {
		return volunteerID;
	}
	public void setVolunteerID(int volunteerID) {
		this.volunteerID = volunteerID;
	}
	public int getTeacherID() {
		return teacherID;
	}
	public void setTeacherID(int teacherID) {
		this.teacherID = teacherID;
	}
	public int getProjectID() {
		return projectID;
	}
	public void setProjectID(int projectID) {
		this.projectID = projectID;
	}
	public String toString() {
		return "参与编号为"+JoinID+"学生编号为"+volunteerID+"老师编号为"+teacherID+"项目编号为"+projectID+"打分为"+score+"";
	}

}
