package com.ssm.po;

public class Volunteer {
	private int volunteerID;
	private String volunteerName;
	private String password;
	public int getVolunteerID() {
		return volunteerID;
	}
	public void setVolunteerID(int volunteerID) {
		this.volunteerID = volunteerID;
	}
	public String getVolunteerName() {
		return volunteerName;
	}
	public void setVolunteerName(String volunteerName) {
		this.volunteerName = volunteerName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String toString() {
		return "志愿者编号=" + volunteerID + ", 志愿者用户名=" + volunteerName+ ", 密码=" + password + "";
	}

}
