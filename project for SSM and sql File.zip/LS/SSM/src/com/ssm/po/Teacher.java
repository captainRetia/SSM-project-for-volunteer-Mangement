package com.ssm.po;

public class Teacher {
	private int teacherID;
	private String teacherName;
	private String password;
	public int getTeacherID() {
		return teacherID;
	}
	public void setTeacherID(int teacherID) {
		this.teacherID = teacherID;
	}
	public String getTeacherName() {
		return teacherName;
	}
	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String toString() {
		return "教师编号=" + teacherID + ", 教师用户名=" + teacherName+ ", 密码=" + password + "";
	}
}
