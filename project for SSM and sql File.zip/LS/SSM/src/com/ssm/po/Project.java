package com.ssm.po;

public class Project {
	private int projectID;
	private String projectName;
	public int getProjectID() {
		return projectID;
	}
	public void setProjectID(int projectID) {
		this.projectID = projectID;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String toString() {
		return "项目编号为" + projectID + ", 项目名称为" + projectName+"";
	}
	
}
	
