package com.ssm.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ssm.po.Project;

public interface ProjectDao {

	public List<Project> selectProjectList(@Param("projectID") int projectID);
	
	public Project findProject(@Param("projectName") String projectName);
	public Project getProjectByProjectId(int projectID);
	public Project getProjectByProjectName(String projectName);
	public int addProject(Project project);
	public int updateProject(Project project);
	public int delProject(int projectID);
}
	


