package com.ssm.dao;

import org.apache.ibatis.annotations.Param;

import com.ssm.po.Admin;



public interface AdminDao {
	
			public Admin findAdmin(@Param("adminName") String volunteerName,@Param("password") String password);
}
