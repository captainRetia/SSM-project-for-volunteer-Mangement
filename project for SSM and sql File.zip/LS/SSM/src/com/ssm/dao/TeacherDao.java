package com.ssm.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ssm.po.Teacher;


public interface TeacherDao {
	public List<Teacher> selectTeacherList(@Param("teacherID") int teacherID);

	public Teacher findTeacher(@Param("teacherName") String teacherName,@Param("password") String password);
	public Teacher getTeacherByTeacherId(int teacherID);
	public Teacher getTeacherByLoginName(String teacherName);
	public int addTeacher(Teacher teacher);
	public int updateTeacher(Teacher teacher);
	public int delTeacher(int teacherID);
}
