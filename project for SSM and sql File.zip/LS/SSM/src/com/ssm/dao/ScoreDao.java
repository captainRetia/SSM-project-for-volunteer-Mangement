package com.ssm.dao;

import org.apache.ibatis.annotations.Param;
import java.util.List;
import com.ssm.po.Score;

public interface ScoreDao {
	 public List<Score> findScoreByvolunteerID(@Param("volunteerID") int volunteerID);
	 public List<Score> findScoreByteacherID(@Param("teacherID") int teacherID);	
	 public List<Score> findScoreByprojectID(@Param("projectID") int projectID);
	 public List<Score> findScoreByvIDandpID(@Param("volunteerID") int volunteerID,@Param("projectID") int projectID);
	 public int addScore(Score score);
	 public int updateVolunteerID(@Param("JoinID") int JoinID,@Param("volunteerID") int volunteerID);
	 public int updateTeacherID(@Param("JoinID") int JoinID,@Param("teacherID") int teacherID);
	 public int delScoreByvIDandpID(@Param("volunteerID") int volunteerID,@Param("projectID") int projectID);
	 public int delScoreBytIDandpID(@Param("teacherID") int teacherID,@Param("projectID") int projectID);
	 public int scoreBypIDandvID(@Param("projectID") int projectID,@Param("volunteerID") int volunteerID,@Param("teacherID") int teacherID,@Param("score") float score);
}
