package com.ssm.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ssm.po.Volunteer;

public interface VolunteerDao {

		public List<Volunteer> selectVolunteerList(@Param("volunteerID") int volunteerID);

		public Volunteer findVolunteer(@Param("volunteerName") String volunteerName,@Param("password") String password);
		public Volunteer getVolunteerByVolunteerId(int volunteerID);
		public Volunteer getVolunteerByLoginName(String volunteerName);
		public int addVolunteer(Volunteer volunteer);
		public int updateVolunteer(Volunteer volunteer);
		public int delVolunteer(int volunteerID);
}
