package com.ssm.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ssm.po.Project;
import com.ssm.po.Teacher;
import com.ssm.po.Volunteer;
import com.ssm.service.ProjectService;
import com.ssm.service.ScoreService;
import com.ssm.service.TeacherService;
import com.ssm.service.VolunteerService;
@Controller
public class ProjectController {
	@Autowired
	private VolunteerService volunteerService;
	@Autowired
	private ScoreService scoreService;
	@Autowired
	private TeacherService teacherService;
	@Autowired
	private ProjectService projectService;
	@RequestMapping(value="/projectAdd.action")
	public String ProjectAdd(String projectName,Model model,HttpSession session){
		int ID=(int) Math.random();
		Project project = new Project();
		project.setProjectID(ID);
		project.setProjectName(projectName);
		Project project2=projectService.findProject(projectName);
		System.out.println(project);
		System.out.println(project2);
		System.out.println(projectName);
				if(project!=null&&project2==null){
				projectService.addProject(project);
				
				List<Project> project4=projectService.findProjectList(1);
				List<Teacher> teacher=teacherService.findTeacherList(1);
				List<Volunteer> volunteer=volunteerService.findVolunteerList(1);
				if(project4.size()!=0) {
					session.setAttribute("volproject", project4);
					}
					else {
						session.removeAttribute("volproject");
						model.addAttribute("msg","目前无项目");
					}
				if(teacher.size()!=0) {
					session.setAttribute("teacher", teacher);
					}
					else {
						session.removeAttribute("teacher");
						model.addAttribute("msg","目前无教师");
					}
				if(volunteer.size()!=0) {
					session.setAttribute("volunteer", volunteer);
					}
					else {
						session.removeAttribute("volunteer");
						model.addAttribute("msg","目前无学生");
					}
				return "admmain";
				}
		model.addAttribute("msg","新增失败，该项目已存在，请重新输入！");
		return "../../projectAdd";
		}
	@RequestMapping(value="/projectDel.action")
	public String projectDel(int projectID,Model model,HttpSession session){
		System.out.println(projectID);
		Project project = new Project();
		project.setProjectID(projectID);
		Project project2=projectService.getProjectByProjectId(projectID);
				if(project2!=null&&project!=null){
				projectService.delProject(projectID);
				List<Project> project4=projectService.findProjectList(1);
				List<Teacher> teacher=teacherService.findTeacherList(1);
				List<Volunteer> volunteer=volunteerService.findVolunteerList(1);
				if(project4.size()!=0) {
					session.setAttribute("volproject", project4);
					}
					else {
						session.removeAttribute("volproject");
						model.addAttribute("msg","目前无项目");
					}
				if(teacher.size()!=0) {
					session.setAttribute("teacher", teacher);
					}
					else {
						session.removeAttribute("teacher");
						model.addAttribute("msg","目前无教师");
					}
				if(volunteer.size()!=0) {
					session.setAttribute("volunteer", volunteer);
					}
					else {
						session.removeAttribute("volunteer");
						model.addAttribute("msg","目前无学生");
					}
				return "admmain";
				}
		model.addAttribute("msg","删除失败，该项目ID不存在，请重新输入！");
		return "../../projectDel";
		}
	
	@RequestMapping(value="projectChange.action")
	 public String updateproject(int projectID,String projectName,Model model,HttpSession session){
	  Project project=new Project();
	  project.setProjectID(projectID);
	  project.setProjectName(projectName);
	   if(projectService.updateProject(project)!=0)
	 {
	 
		   List<Project> project4=projectService.findProjectList(1);
			List<Teacher> teacher=teacherService.findTeacherList(1);
			List<Volunteer> volunteer=volunteerService.findVolunteerList(1);
			if(project4.size()!=0) {
				session.setAttribute("volproject", project4);
				}
				else {
					session.removeAttribute("volproject");
					model.addAttribute("msg","目前无项目");
				}
			if(teacher.size()!=0) {
				session.setAttribute("teacher", teacher);
				}
				else {
					session.removeAttribute("teacher");
					model.addAttribute("msg","目前无教师");
				}
			if(volunteer.size()!=0) {
				session.setAttribute("volunteer", volunteer);
				}
				else {
					session.removeAttribute("volunteer");
					model.addAttribute("msg","目前无学生");
				}
			return "admmain";
	 }
	 else
	 {
	  model.addAttribute("msg","修改失败，请重新登入验证！");
	  return"../../projectChange";
	 }
	    }
}
