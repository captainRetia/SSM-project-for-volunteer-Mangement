package com.ssm.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ssm.po.Project;
import com.ssm.po.Score;
import com.ssm.po.Teacher;
import com.ssm.po.Volunteer;
import com.ssm.service.ProjectService;
import com.ssm.service.ScoreService;
import com.ssm.service.TeacherService;
import com.ssm.service.VolunteerService;
@Controller

public class TeacherController {
	@Autowired
	private VolunteerService volunteerService;
	@Autowired
	private ScoreService scoreService;
	@Autowired
	private TeacherService teacherService;
	@Autowired
	private ProjectService projectService;
	@RequestMapping(value="/teacherlogin.action")
	public String teacherlogin(String teacherName,String password,Model model,HttpSession session){
		Teacher teacher=teacherService.findTeacher(teacherName, password);
				if(teacher!=null){
				session.setAttribute("login_teacher", teacher);
				List<Project> project=projectService.findProjectList(1);
				List<Score> score=scoreService.findScoreByteacherID(teacher.getTeacherID());
				if(project.size()!=0) {
				session.setAttribute("volproject", project);
				}
				else {
					session.removeAttribute("volproject");
					model.addAttribute("msg","目前无项目");
				}
				if(score.size()!=0) {
					session.setAttribute("voljoin", score);
					System.out.println(score);
					}
				else {
					session.removeAttribute("voljoin");
					model.addAttribute("msg","目前未参加项目");
				}
				return "teamain";
				
		}
				
		model.addAttribute("msg","账号或密码错误，请重新登录！");
		return "../../teacherLogin";
				
	}
	@RequestMapping(value="/teacherRegister.action")
	public String teacherRegister(String teacherName,String password,Model model,HttpSession session){
		int ID=(int) Math.random();
		Teacher teacher = new Teacher();
		teacher.setTeacherID(ID);
		teacher.setTeacherName(teacherName);
		teacher.setPassword(password);
		Teacher teacher2=teacherService.findTeacher(teacherName, password);
		System.out.println(teacher);
		System.out.println(teacher2);
		System.out.println(teacherName);
				if(teacher!=null&&teacher2==null){
					teacherService.addTeacher(teacher);
				session.setAttribute("login_teacher", teacher2);
				List<Project> project=projectService.findProjectList(1);
				if(project.size()!=0) {
					session.setAttribute("volproject", project);
					}
				else {
					session.removeAttribute("volproject");
					model.addAttribute("msg","目前无项目");
				}
				return "teamain";
				
		}
				
		model.addAttribute("msg","注册失败，请重新输入！");
		return "../../teacherRegister";
	}
	@RequestMapping(value="/takeProject.action")
	public String teachertakeProject(int projectID,Model model,HttpSession session)
	{
		Teacher t=(Teacher) session.getAttribute("login_teacher");
		List<Project> project=projectService.findProjectList(1);
		int teacherID=t.getTeacherID();
		
		List<Score> sc=scoreService.findScoreByprojectID(projectID);
		if(sc.size()!=0)
		{
			for(int i=0;i<sc.size();i++)
			{
				Score s=sc.get(i);
				if(s.getTeacherID()==0)
				{
					scoreService.updateTeacherID(s.getJoinID(),teacherID);
				}
				else if(s.getTeacherID()==teacherID)
				{
					continue;
				}
				else {
					s.setJoinID((int) Math.random());
					s.setTeacherID(teacherID);
					s.setScore(0);
					scoreService.addScore(s);				
					}
			}
		}
		else {
			Score temp=new Score();
			int ID=(int) Math.random();
			temp.setJoinID(ID);
			temp.setProjectID(projectID);
			temp.setTeacherID(teacherID);
			scoreService.addScore(temp);
		}
		
		
		List<Score> score=scoreService.findScoreByteacherID(teacherID);
		if(project.size()!=0) {
		session.setAttribute("volproject", project);
		}
		else {
			session.removeAttribute("volproject");
			model.addAttribute("msg","目前无项目");
		}
		if(score.size()!=0) {
			session.setAttribute("voljoin", score);
			System.out.println(score);
			}
		else {
			session.removeAttribute("voljoin");
			model.addAttribute("msg","目前未参加项目");
		}
		return "teamain";
	}
	@RequestMapping(value="/leaveProject.action")
	public String teacherleaveProject(int projectID,Model model,HttpSession session)
	{
		Teacher t=(Teacher) session.getAttribute("login_teacher");
		int teacherID=t.getTeacherID();
		if(scoreService.delScoreBytIDandpID(teacherID, projectID)!=0)
		{
			model.addAttribute("msg","退出成功");
		}
		else {
			model.addAttribute("msg","退出失败");
		}
		
		List<Project> project=projectService.findProjectList(1);
		List<Score> score=scoreService.findScoreByteacherID(teacherID);
		if(project.size()!=0) {
		session.setAttribute("volproject", project);
		}
		else {
			session.removeAttribute("volproject");
			model.addAttribute("msg","目前无项目");
		}
		if(score.size()!=0) {
			session.setAttribute("voljoin", score);
			System.out.println(score);
			}
		else {
			session.removeAttribute("voljoin");
			model.addAttribute("msg","目前未参加项目");
		}
		return "teamain";
	}
	@RequestMapping(value="/changeScore.action")
	public String teacherchangeScore(int projectID,int volunteerID,float score,Model model,HttpSession session)
	{
		Teacher t=(Teacher) session.getAttribute("login_teacher");
		int teacherID=t.getTeacherID();
		if(scoreService.scoreBypIDandvID(projectID, volunteerID, teacherID,score)!=0)
		{
			model.addAttribute("msg","打分成功");
		}
		else {
			model.addAttribute("msg","打分失败");
		}
		
		List<Project> project=projectService.findProjectList(1);
		List<Score> scorep=scoreService.findScoreByteacherID(teacherID);
		if(project.size()!=0) {
		session.setAttribute("volproject", project);
		}
		else {
			session.removeAttribute("volproject");
			model.addAttribute("msg","目前无项目");
		}
		if(scorep.size()!=0) {
			session.setAttribute("voljoin", scorep);
			System.out.println(scorep);
			}
		else {
			session.removeAttribute("voljoin");
			model.addAttribute("msg","目前未参加项目");
		}
		return "teamain";
	}
	@RequestMapping(value="/teacherAdd.action")
	public String TeacherAdd(String teacherName,String password,Model model,HttpSession session){
		int ID=(int) Math.random();
		Teacher teacher = new Teacher();
		teacher.setTeacherID(ID);
		teacher.setTeacherName(teacherName);
		teacher.setPassword(password);
		Teacher teacher2=teacherService.findTeacher(teacherName, password);
		System.out.println(teacher);
		System.out.println(teacher2);
		System.out.println(teacherName);
				if(teacher!=null&&teacher2==null){
				teacherService.addTeacher(teacher);

				List<Project> project=projectService.findProjectList(1);
				List<Teacher> teacher4=teacherService.findTeacherList(1);
				List<Volunteer> volunteer=volunteerService.findVolunteerList(1);
				if(project.size()!=0) {
					session.setAttribute("volproject", project);
					}
					else {
						session.removeAttribute("volproject");
						model.addAttribute("msg","目前无项目");
					}
				if(teacher4.size()!=0) {
					session.setAttribute("teacher", teacher4);
					}
					else {
						session.removeAttribute("teacher");
						model.addAttribute("msg","目前无教师");
					}
				if(volunteer.size()!=0) {
					session.setAttribute("volunteer", volunteer);
					}
					else {
						session.removeAttribute("volunteer");
						model.addAttribute("msg","目前无学生");
					}
				
				return "admmain";
				}
		model.addAttribute("msg","新增失败，该账号密码已存在，请重新输入！");
		return "../../teacherAdd";
		}
	@RequestMapping(value="/teacherDel.action")
	public String teacherDel(int teacherID,Model model,HttpSession session){
		System.out.println(teacherID);
		Teacher teacher = new Teacher();
		teacher.setTeacherID(teacherID);
		Teacher teacher2=teacherService.getTeacherByTeacherId(teacherID);
				if(teacher2!=null&&teacher!=null){
				teacherService.delTeacher(teacherID);
				
				List<Project> project=projectService.findProjectList(1);
				List<Teacher> teacher4=teacherService.findTeacherList(1);
				List<Volunteer> volunteer=volunteerService.findVolunteerList(1);
				if(project.size()!=0) {
					session.setAttribute("volproject", project);
					}
					else {
						session.removeAttribute("volproject");
						model.addAttribute("msg","目前无项目");
					}
				if(teacher4.size()!=0) {
					session.setAttribute("teacher", teacher4);
					}
					else {
						session.removeAttribute("teacher");
						model.addAttribute("msg","目前无教师");
					}
				if(volunteer.size()!=0) {
					session.setAttribute("volunteer", volunteer);
					}
					else {
						session.removeAttribute("volunteer");
						model.addAttribute("msg","目前无学生");
					}
				return "admmain";
				}
		model.addAttribute("msg","删除失败，该教师ID不存在，请重新输入！");
		return "../../teacherDel";
		}
	
	@RequestMapping(value="teacherChange.action")
	 public String updateteacher(int teacherID,String teacherName,String password,Model model,HttpSession session){
	  Teacher teacher=new Teacher();
	  teacher.setTeacherID(teacherID);
	  teacher.setTeacherName(teacherName);
	  teacher.setPassword(password);
	   if(teacherService.updateTeacher(teacher)!=0)
	 {
	 
		   List<Project> project=projectService.findProjectList(1);
			List<Teacher> teacher4=teacherService.findTeacherList(1);
			List<Volunteer> volunteer=volunteerService.findVolunteerList(1);
			if(project.size()!=0) {
				session.setAttribute("volproject", project);
				}
				else {
					session.removeAttribute("volproject");
					model.addAttribute("msg","目前无项目");
				}
			if(teacher4.size()!=0) {
				session.setAttribute("teacher", teacher4);
				}
				else {
					session.removeAttribute("teacher");
					model.addAttribute("msg","目前无教师");
				}
			if(volunteer.size()!=0) {
				session.setAttribute("volunteer", volunteer);
				}
				else {
					session.removeAttribute("volunteer");
					model.addAttribute("msg","目前无学生");
				}
			return "admmain";
	 }
	 else
	 {
	  model.addAttribute("msg","修改失败，请重新登入验证！");
	  return"../../teacherChange";
	 }
	    }
}
