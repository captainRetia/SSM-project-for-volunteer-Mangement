package com.ssm.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ssm.po.Project;
import com.ssm.po.Score;
import com.ssm.po.Teacher;
import com.ssm.po.Volunteer;
import com.ssm.service.ProjectService;
import com.ssm.service.ScoreService;
import com.ssm.service.TeacherService;
import com.ssm.service.VolunteerService;
@Controller

public class VolunteerController {
	@Autowired
	private TeacherService teacherService;
	@Autowired
	private VolunteerService volunteerService;
	@Autowired
	private ProjectService projectService;
	@Autowired
	private ScoreService scoreService;
	@RequestMapping(value="/volunteerlogin.action")
	public String volunteerlogin(String volunteerName,String password,Model model,HttpSession session){
		//通过志愿者姓名和密码查询志愿者
		
		Volunteer volunteer=volunteerService.findVolunteer(volunteerName, password);
				if(volunteer!=null){
				session.setAttribute("login_volunteer", volunteer);
				List<Project> project=projectService.findProjectList(1);
				List<Score> score=scoreService.findScoreByvolunteerID(volunteer.getVolunteerID());
				if(project.size()!=0) {
					session.setAttribute("volproject", project);
					}
				else {
					session.removeAttribute("volproject");
					model.addAttribute("msg","目前无项目");
				}
				if(score.size()!=0) {
					session.setAttribute("voljoin", score);
					System.out.println(score);
					}
				else {
					session.removeAttribute("voljoin");
					model.addAttribute("msg","目前未参加项目");
				}
				return "volmain";
				
		}
				
		model.addAttribute("msg","账号或密码错误，请重新登录！");
		return "../../volunteerLogin";
				
	}
	@RequestMapping(value="/volunteerRegister.action")
	public String volunteerRegister(String volunteerName,String password,Model model,HttpSession session){
		//通过志愿者姓名和密码查询志愿者
		int ID=(int) Math.random();
		Volunteer volunteer = new Volunteer();
		volunteer.setVolunteerID(ID);
		volunteer.setVolunteerName(volunteerName);
		volunteer.setPassword(password);
		Volunteer volunteer2=volunteerService.findVolunteer(volunteerName, password);
		System.out.println(volunteer);
		System.out.println(volunteer2);
		System.out.println(volunteerName);
				if(volunteer!=null&&volunteer2==null){
				volunteerService.addVolunteer(volunteer);
				session.setAttribute("login_volunteer", volunteer2);
				List<Project> project=projectService.findProjectList(1);
				if(project.size()!=0) {
					session.setAttribute("volproject", project);
					}
				else {
					session.removeAttribute("volproject");
					model.addAttribute("msg","目前无项目");
				}
				return "volmain";
				
		}
				
		model.addAttribute("msg","注册失败，请重新输入！");
		return "../../volunteerRegister";
				
	}
	@RequestMapping(value="/enterProject.action")
	public String volunteerenterProject(int projectID,Model model,HttpSession session){
		List<Project> project=projectService.findProjectList(1);
		Volunteer volunteer=(Volunteer) session.getAttribute("login_volunteer");
		
		List<Score> sc=scoreService.findScoreByprojectID(projectID);
		if(sc.size()!=0)
		{
			for(int i=0;i<sc.size();i++)
			{
				Score s=sc.get(i);
				if(s.getVolunteerID()==0)
				{
					scoreService.updateVolunteerID(s.getJoinID(), volunteer.getVolunteerID());
				}
				else if(s.getVolunteerID()==volunteer.getVolunteerID())
				{
					continue;
				}
				else {
					s.setJoinID((int) Math.random());
					s.setVolunteerID(volunteer.getVolunteerID());
					s.setScore(0);
					scoreService.addScore(s);
					}
			}
		}
		else {
			Score temp=new Score();
			int ID=(int) Math.random();
			temp.setJoinID(ID);
			temp.setProjectID(projectID);
			temp.setVolunteerID(volunteer.getVolunteerID());
			scoreService.addScore(temp);

		}
		List<Score> score=scoreService.findScoreByvolunteerID(volunteer.getVolunteerID());	
		if(project.size()!=0) {
			session.setAttribute("volproject", project);
			}
		else {
			session.removeAttribute("volproject");
			model.addAttribute("msg","目前无项目");
		}
		if(score.size()!=0) {
			session.setAttribute("voljoin", score);
			System.out.println(score);
			}
		else {
			session.removeAttribute("voljoin");
			model.addAttribute("msg","目前未参加项目");
		}
		return "volmain";
		
				
	}
	@RequestMapping(value="/quitProject.action")
	public String volunteerquitProject(int projectID,Model model,HttpSession session){
		List<Project> project=projectService.findProjectList(1);
		Volunteer volunteer=(Volunteer) session.getAttribute("login_volunteer");
		int volunteerID=volunteer.getVolunteerID();
		if(scoreService.delScoreByvIDandpID(volunteerID, projectID)!=0)
		{
			model.addAttribute("msg","退出成功");
		}
		else {
			model.addAttribute("msg","退出失败");
		}
		
		List<Score> score=scoreService.findScoreByvolunteerID(volunteerID);	
		if(project.size()!=0) {
			session.setAttribute("volproject", project);
			}
		else {
			session.removeAttribute("volproject");
			model.addAttribute("msg","目前无项目");
		}
		if(score.size()!=0) {
			session.setAttribute("voljoin", score);
			System.out.println(score);
			}
		else {
			session.removeAttribute("voljoin");
			model.addAttribute("msg","目前未参加项目");
		}
		return "volmain";
		
				
	}
	@RequestMapping(value="/volunteerAdd.action")
	public String volunteerAdd(String volunteerName,String password,Model model,HttpSession session){
		int ID=(int) Math.random();
		Volunteer volunteer = new Volunteer();
		volunteer.setVolunteerID(ID);
		volunteer.setVolunteerName(volunteerName);
		volunteer.setPassword(password);
		Volunteer volunteer2=volunteerService.findVolunteer(volunteerName, password);
		System.out.println(volunteer);
		System.out.println(volunteer2);
		System.out.println(volunteerName);
				if(volunteer!=null&&volunteer2==null){
				volunteerService.addVolunteer(volunteer);
				
				List<Project> project=projectService.findProjectList(1);
				List<Teacher> teacher4=teacherService.findTeacherList(1);
				List<Volunteer> volunteer5=volunteerService.findVolunteerList(1);
				if(project.size()!=0) {
					session.setAttribute("volproject", project);
					}
					else {
						session.removeAttribute("volproject");
						model.addAttribute("msg","目前无项目");
					}
				if(teacher4.size()!=0) {
					session.setAttribute("teacher", teacher4);
					}
					else {
						session.removeAttribute("teacher");
						model.addAttribute("msg","目前无教师");
					}
				if(volunteer5.size()!=0) {
					session.setAttribute("volunteer", volunteer5);
					}
					else {
						session.removeAttribute("volunteer");
						model.addAttribute("msg","目前无学生");
					}
				
				return "admmain";
				}
		model.addAttribute("msg","新增失败，该账号密码已存在，请重新输入！");
		return "../../volunteerAdd";
		}
	@RequestMapping(value="/volunteerDel.action")
	public String volunteerDel(int volunteerID,Model model,HttpSession session){
		System.out.println(volunteerID);
		Volunteer volunteer = new Volunteer();
		volunteer.setVolunteerID(volunteerID);
		Volunteer volunteer2=volunteerService.getVolunteerByVolunteerId(volunteerID);
				if(volunteer2!=null&&volunteer!=null){
				volunteerService.delVolunteer(volunteerID);
				
				List<Project> project=projectService.findProjectList(1);
				List<Teacher> teacher4=teacherService.findTeacherList(1);
				List<Volunteer> volunteer5=volunteerService.findVolunteerList(1);
				if(project.size()!=0) {
					session.setAttribute("volproject", project);
					}
					else {
						session.removeAttribute("volproject");
						model.addAttribute("msg","目前无项目");
					}
				if(teacher4.size()!=0) {
					session.setAttribute("teacher", teacher4);
					}
					else {
						session.removeAttribute("teacher");
						model.addAttribute("msg","目前无教师");
					}
				if(volunteer5.size()!=0) {
					session.setAttribute("volunteer", volunteer5);
					}
					else {
						session.removeAttribute("volunteer");
						model.addAttribute("msg","目前无学生");
					}
				return "admmain";
				}
		model.addAttribute("msg","删除失败，该学生ID不存在，请重新输入！");
		return "../../volunteerDel";
		}
	
	@RequestMapping(value="volunteerChange.action")
	 public String updateVolunteer(int volunteerID,String volunteerName,String password,Model model,HttpSession session){
	   Volunteer volunteer=new Volunteer();
	   volunteer.setVolunteerID(volunteerID);
	   volunteer.setVolunteerName(volunteerName);
	   volunteer.setPassword(password);
	   if(volunteerService.updateVolunteer(volunteer)!=0)
	 {
		   
		  List<Project> project=projectService.findProjectList(1);
			List<Teacher> teacher4=teacherService.findTeacherList(1);
			List<Volunteer> volunteer5=volunteerService.findVolunteerList(1);
			System.out.println(volunteer5);
			if(project.size()!=0) {
				session.setAttribute("volproject", project);
				}
				else {
					session.removeAttribute("volproject");
					model.addAttribute("msg","目前无项目");
				}
			if(teacher4.size()!=0) {
				session.setAttribute("teacher", teacher4);
				}
				else {
					session.removeAttribute("teacher");
					model.addAttribute("msg","目前无教师");
				}
			if(volunteer5.size()!=0) {
				session.setAttribute("volunteer", volunteer5);
				}
				else {
					session.removeAttribute("volunteer");
					model.addAttribute("msg","目前无学生");
				}
			return "admmain";
	 }
	 else
	 {
	  model.addAttribute("msg","修改失败，请重新登入验证！");
	  return"../../volunteerChange";
	 }
	 }
}
