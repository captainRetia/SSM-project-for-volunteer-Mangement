package com.ssm.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ssm.po.Admin;
import com.ssm.po.Project;
import com.ssm.po.Teacher;
import com.ssm.po.Volunteer;
import com.ssm.service.AdminService;
import com.ssm.service.ProjectService;
import com.ssm.service.TeacherService;
import com.ssm.service.VolunteerService;

@Controller
public class AdminController {
	@Autowired
	private VolunteerService volunteerService;
	@Autowired
	private TeacherService teacherService;
	@Autowired
	private ProjectService projectService;
	@Autowired
	private AdminService adminService;
    @RequestMapping(value="/adminlogin.action")
    public String adminlogin(String adminName,String password,Model model,HttpSession session){
		//通过志愿者姓名和密码查询志愿者
		System.out.println(adminName);
		Admin admin=adminService.findAdmin(adminName, password);
				if(admin!=null){
				session.setAttribute("login_admin", admin);
				List<Project> project=projectService.findProjectList(1);
				List<Teacher> teacher=teacherService.findTeacherList(1);
				List<Volunteer> volunteer=volunteerService.findVolunteerList(1);
				if(project.size()!=0) {
					session.setAttribute("volproject", project);
					}
					else {
						session.removeAttribute("volproject");
						model.addAttribute("msg","目前无项目");
					}
				if(teacher.size()!=0) {
					session.setAttribute("teacher", teacher);
					}
					else {
						session.removeAttribute("teacher");
						model.addAttribute("msg","目前无教师");
					}
				if(volunteer.size()!=0) {
					session.setAttribute("volunteer", volunteer);
					}
					else {
						session.removeAttribute("volunteer");
						model.addAttribute("msg","目前无学生");
					}
				return "admmain";
				
		}
				
		model.addAttribute("msg","账号或密码错误，请重新登录！");
		return "../../adminLogin";
				
	}
}
