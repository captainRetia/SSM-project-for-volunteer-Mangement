package com.ssm.service;

import java.util.List;

import com.ssm.po.Volunteer;

public interface VolunteerService {
	public List<Volunteer> findVolunteerList(int volunteerID);
	public Volunteer findVolunteer(String volunteerName,String password);
	public Volunteer getVolunteerByVolunteerId(int volunteerID);
	public Volunteer getVolunteerByLoginName(String volunteerName);
	public int updateVolunteer(Volunteer volunteer);
	public int addVolunteer(Volunteer volunteer);
	public int delVolunteer(int volunteerID);
}
