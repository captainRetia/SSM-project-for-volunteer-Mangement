package com.ssm.service;

import java.util.List;

import com.ssm.po.Project;

public interface ProjectService {
	public List<Project> findProjectList(int projectID);
	public Project findProject(String ProjectName);
	public Project getProjectByProjectId(int projectID);
	public Project getProjectByProjectName(String projectName);
	public int updateProject(Project project);
	public int addProject(Project project);
	public int delProject(int projectID);
}
