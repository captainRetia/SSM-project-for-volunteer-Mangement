package com.ssm.service;

import java.util.List;


import com.ssm.po.Score;

public interface ScoreService {
	public List<Score> findScoreByvolunteerID(int volunteerID);
	public List<Score> findScoreByteacherID(int teacherID);
	 public List<Score> findScoreByprojectID(int projectID);
	public List<Score> findScoreByvIDandpID(int volunteerID,int projectID);
	public int addScore(Score score);
	 public int updateVolunteerID(int JoinID,int volunteerID);
	 public int updateTeacherID(int JoinID,int teacherID);
	public int delScoreByvIDandpID(int volunteerID,int projectID);
	public int delScoreBytIDandpID(int teacherID,int projectID);
	public int scoreBypIDandvID(int projectID,int volunteerID,int teacherID,float score);
}
