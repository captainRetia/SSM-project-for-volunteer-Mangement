package com.ssm.service;

import com.ssm.po.Admin;

public interface AdminService {
	public Admin findAdmin(String adminName,String password);

}
