package com.ssm.service;

import java.util.List;

import com.ssm.po.Teacher;

public interface TeacherService {
	public List<Teacher> findTeacherList(int teacherID);
	public Teacher findTeacher(String teacherName,String password);
	public Teacher getTeacherByTeacherId(int teacherID);
	public Teacher getTeacherByLoginName(String teacherName);
	public int addTeacher(Teacher teacher);
	public int updateTeacher(Teacher teacher);
	public int delTeacher(int teacherID);
}
