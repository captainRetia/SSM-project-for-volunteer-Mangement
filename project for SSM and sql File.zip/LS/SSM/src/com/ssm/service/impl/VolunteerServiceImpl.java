package com.ssm.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssm.dao.VolunteerDao;
import com.ssm.po.Volunteer;
import com.ssm.service.VolunteerService;
@Service("VolunteerService")
public class VolunteerServiceImpl implements VolunteerService {
	@Autowired
	private VolunteerDao volunteerDao;
	@Override
	public List<Volunteer> findVolunteerList(int volunteerID){
		List<Volunteer> volunteerList=this.volunteerDao.selectVolunteerList(volunteerID);
		return volunteerList;
	}
	@Override
	public Volunteer findVolunteer(String volunteerName,String password) {
		Volunteer volunteer=this.volunteerDao.findVolunteer(volunteerName, password);
		return volunteer;
	}
	@Override
	public Volunteer getVolunteerByVolunteerId(int volunteerId) {
		return this.volunteerDao.getVolunteerByVolunteerId(volunteerId);
	}
	@Override
	public Volunteer getVolunteerByLoginName(String volunteerName) {
		return this.volunteerDao.getVolunteerByLoginName(volunteerName);
	}
	@Override
	public int updateVolunteer(Volunteer volunteer) {
		return this.volunteerDao.updateVolunteer(volunteer);
	}
	@Override
	public int addVolunteer(Volunteer volunteer) {
		return this.volunteerDao.addVolunteer(volunteer);
	}
	@Override
	public int delVolunteer(int volunteerId) {
		return this.volunteerDao.delVolunteer(volunteerId);
	}
}
