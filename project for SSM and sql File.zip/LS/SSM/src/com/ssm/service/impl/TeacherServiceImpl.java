package com.ssm.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssm.dao.TeacherDao;
import com.ssm.po.Teacher;
import com.ssm.service.TeacherService;
@Service("TeacherService")
public class TeacherServiceImpl implements TeacherService {
	@Autowired
	private TeacherDao teacherDao;
	@Override
	public List<Teacher> findTeacherList(int teacherID) {
		List<Teacher> teacherList=this.teacherDao.selectTeacherList(teacherID);
		return teacherList;
	}

	@Override
	public Teacher findTeacher(String teacherName, String password) {
		Teacher teacher=this.teacherDao.findTeacher(teacherName, password);
		return teacher;
	}

	@Override
	public Teacher getTeacherByTeacherId(int teacherID) {
		return this.teacherDao.getTeacherByTeacherId(teacherID);
	}

	@Override
	public Teacher getTeacherByLoginName(String teacherName) {
		// TODO Auto-generated method stub
		return this.teacherDao.getTeacherByLoginName(teacherName);
	}

	@Override
	public int addTeacher(Teacher teacher) {
		// TODO Auto-generated method stub
		return this.teacherDao.addTeacher(teacher);
	}

	@Override
	public int updateTeacher(Teacher teacher) {
		// TODO Auto-generated method stub
		return this.teacherDao.updateTeacher(teacher);
	}

	@Override
	public int delTeacher(int teacherID) {
		// TODO Auto-generated method stub
		return this.teacherDao.delTeacher(teacherID);
	}

}
