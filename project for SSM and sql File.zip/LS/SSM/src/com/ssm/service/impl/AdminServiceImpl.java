package com.ssm.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssm.dao.AdminDao;
import com.ssm.po.Admin;
import com.ssm.service.AdminService;
@Service("AdminService")
public class AdminServiceImpl implements AdminService {
	@Autowired
	private AdminDao adminDao;
	@Override
	public Admin findAdmin(String adminName, String password) {
		Admin admin=this.adminDao.findAdmin(adminName, password);
		return admin;
	}

}
