package com.ssm.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssm.dao.ProjectDao;

import com.ssm.po.Project;

import com.ssm.service.ProjectService;
@Service("ProjectService")
public class ProjectServiceImpl implements ProjectService {
	@Autowired
	private ProjectDao projectDao;
	@Override
	public List<Project> findProjectList(int projectID) {
		List<Project> projectList=this.projectDao.selectProjectList(projectID);
		return projectList;
	}

	@Override
	public Project findProject(String ProjectName) {
		Project project=this.projectDao.findProject(ProjectName);
		return project;
	}
	@Override
	public Project getProjectByProjectId(int ProjectId) {
		return this.projectDao.getProjectByProjectId(ProjectId);
	}
	@Override
	public Project getProjectByProjectName(String ProjectName) {
		return this.projectDao.getProjectByProjectName(ProjectName);
	}
	@Override
	public int updateProject(Project Project) {
		return this.projectDao.updateProject(Project);
	}
	@Override
	public int addProject(Project Project) {
		return this.projectDao.addProject(Project);
	}
	@Override
	public int delProject(int projectID) {
		return this.projectDao.delProject(projectID);
	}
}
