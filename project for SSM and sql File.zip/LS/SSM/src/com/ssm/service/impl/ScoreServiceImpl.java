package com.ssm.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ssm.dao.ScoreDao;
import com.ssm.po.Score;
import com.ssm.service.ScoreService;
@Service("ScoreService")
public class ScoreServiceImpl implements ScoreService {
	
	@Autowired
	private ScoreDao scoreDao;
	@Override
	public List<Score> findScoreByvolunteerID(int volunteerID) {
		List<Score> score=this.scoreDao.findScoreByvolunteerID(volunteerID);
		return score;
	}
	@Override
	public List<Score> findScoreByteacherID(int teacherID) {
		List<Score> score=this.scoreDao.findScoreByteacherID(teacherID);
		return score;
	}
	@Override
	public List<Score> findScoreByvIDandpID(int volunteerID, int projectID) {
		List<Score> score=this.scoreDao.findScoreByvIDandpID(volunteerID, projectID);
		return score;
	}
	@Override
	public int addScore(Score score) {
		return this.scoreDao.addScore(score);
	}
	@Override
	public int delScoreByvIDandpID(int volunteerID, int projectID) {
		return this.scoreDao.delScoreByvIDandpID(volunteerID, projectID);
	}
	@Override
	public int delScoreBytIDandpID(int teacherID, int projectID) {
		return this.scoreDao.delScoreBytIDandpID(teacherID, projectID);
	}
	@Override
	public int scoreBypIDandvID(int projectID, int volunteerID, int teacherID,float score) {
		return this.scoreDao.scoreBypIDandvID(projectID, volunteerID, teacherID,score);
	}
	@Override
	public List<Score> findScoreByprojectID(int projectID) {
		List<Score> score=this.scoreDao.findScoreByprojectID(projectID);
		return score;
	}
	@Override
	public int updateVolunteerID(int JoinID,int volunteerID) {
		return this.scoreDao.updateVolunteerID(JoinID,volunteerID);
	}
	@Override
	public int updateTeacherID(int JoinID,int volunteerID) {
		return this.scoreDao.updateTeacherID(JoinID,volunteerID);
	}

}
